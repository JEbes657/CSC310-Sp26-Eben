This is the folder with all of my Splay tree programs in it. One folder has the topdown approach while the other have a bottom-up approach
Additionally there is the semisplay and the weighted splay in the top-down folder. I would like to point out one point out one possible discrepancy in the way these files were timed.
I changed the timer to the steady clock as it is better for timing and can provide more accurate timing data.

I'm hoping that the code itself will be a little easier to follow now that my main is a lot simpler and follows a more condensed and clean structure.