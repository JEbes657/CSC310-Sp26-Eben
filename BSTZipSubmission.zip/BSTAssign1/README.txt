This is the full BST function. You must run both the BSTProgram executable and add another file
to that same line for the function to work properly. There are three files that handle all cases
you would see when running the search tree. The aim is for each file to highlight some scenario
that shows all the implimentation required in A0.